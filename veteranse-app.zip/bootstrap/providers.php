<?php

return [
    App\Providers\AppServiceProvider::class,
    App\Services\Cart\CartServiceProvider::class,
];
